
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="css/main.css">
<link rel="stylesheet" href="css/popupLogin.css">
<script src="js/popupLogin.js"></script>
<script src="https://kit.fontawesome.com/6bcee8e3da.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<link rel="stylesheet" href="https://cdn.materialdesignicons.com/4.5.95/css/materialdesignicons.min.css">


<?php
  //session_start();
  $username=null;

  require 'item_process_controller.php';
  include 'popupLogin.php';

  if(isset($_SESSION['username'])){
    $username=$_SESSION['username'];
  }
 ?>


<div class="div-navi-bar">
  <div class="dvi-gg">
    <div class="div-navi-logo">
      <img src="img\salezone-logo-1522230747.jpg" >
    </div>
    <div class="div-cart">
      <a href="cart.php"><span class="mdi mdi-cart-outline"></span></a>
      <div class="div-cart-info">
        <label>Cart</label>
        <p><span id="cartItemCount">0</span> items</p>
      </div>
    </div>
    <div class="div-track-order">
      <i class="far fa-bell"></i>
    </div>
    <div class="div-searchbar">
      <i class="fas fa-search"></i>
      <input class="form-control" id="myInput" type="text" placeholder="Search"  >
    </div>
  </div>
  <div class="div-navi">
    <ul>
      <li><a href="index.php">Home</a></li>
      <li><a href="shopping.php">Shopping</a></li>
      <?php if (isset($_SESSION['role'])) {
        if ($_SESSION['role'] == 'admin') { ?>
      <li><a href='Admin-Order.php'>Admin</a></li>";
       <?php } } ?>
    </ul>
    <div class="div-navi-acc">
      <?php
      if (isset($_SESSION['username'])) {
        echo "<a href='user_profile.php'><span>  $username </span></a>";
        if (isset($current_url)) {
          echo "<a href='userConfig.php?action=logout&url=$current_url'>Logout</a> ";
        }else {
          echo "<a href='userConfig.php?action=logout'>Logout</a> ";
        }

      }else {
        echo "<a onclick='loginCheck()'>Login</a>";
        echo "<a href='register.php'>Register</a>";
      }
      ?>
    </div>
  </div>
</div>

<!--popuplogin div -->
<div id="div-popup" class="div-popup" onclick="popDivClose()"></div>
<div id="div-popup-login" class="div-popup-loging">
  <!--  <input type="text" id="popScript" name="" value="<?php //if (isset($_SESSION['popLogin'])) {echo $_SESSION['popLogin'];} ?>"> -->
  <div class="div-login-title">
    <h3> Please Login to continue.</h3>
    <span>New member? <a href="register.php">Register here</a></span>
  </div>
  <div class="div-popup-devide">
    <div class="div-popup-devide-left">
      <form class="" action="userConfig.php" method="post">
        <!-- $url is in relative page -->
        <input type="hidden" name="url" value="<?php echo $current_url  ?>">
        <!-- id=='uname' for checking uname,for loginCheck() function; -->
        <input type="hidden" id="uname" name="uid" value="<?php echo $username ?>">
        <label>Username</label>
        <input type="text" name="uname" value="">
        <label>Password</label>
        <input type="password" name="pass" value="">
        <div class="">
          <button type="submit" name="btn_login">Login</button>
        </div>
      </form>
    </div>
  </div>
</div>
<script type="text/javascript">
  var dis_iTid = JSON.parse(sessionStorage.getItem("added_iTid"));
  var dis_iamount = JSON.parse(sessionStorage.getItem("added_iamount"));
  var dis_itotcost = JSON.parse(sessionStorage.getItem("added_itotcost"));

  if (!dis_iTid.length || !Array.isArray(dis_iTid)) {
    document.getElementById("cartItemCount").innerHTML=0;
  }else{
    var count=dis_iTid.length;
    document.getElementById("cartItemCount").innerHTML=count;
  }
</script>
