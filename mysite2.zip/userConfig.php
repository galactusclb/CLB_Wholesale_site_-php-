<?php
  session_start();
  
  //require 'item_process_controller.php';
   $mysqli = new mysqli('localhost','id11536653_clbwholesale','16InDJ5V2SoODxeHtw!Y','id11536653_wholesale') or die(mysqli_error($mysqli));


  if (isset($_POST['btn_login'])) {
    $uname=$_POST['uname'];
    $pass=$_POST['pass'];

    $result = $mysqli-> query("select * from users where uname='$uname' and pass= '$pass' ") or die ($mysqli->error());

    

    if($result->num_rows){
       while ($row=$result->fetch_assoc()) {
         $_SESSION['username'] = $uname;
         $_SESSION['role'] = $row['role'];
    
         if (!isset($_POST['url'])) {
            header("Location: shopping.php");
         }else {
            header("Location: {$_POST['url']}");
          }
       }
    }else {
      //$_SESSION['popLogin'] = "window.addEventListener('load', loginCheck);";
      if (isset($_POST['url'])) {
        header("Location: {$_POST['url']}");
      }else {
        header("Location: login.php");
       }
     }

  }

  if (isset($_POST['btn_register'])) {
    $uname=$_POST['uname'];
    $pass=$_POST['pass'];

    $result = $mysqli->query("insert into users (uname,pass,role) values('$uname','$pass','user')") or die ($mysqli->error());

    if($result->num_rows){
      header("Location: login.php");
    }else{
      header("Location: asd.php");
    }
  }


  if (isset($_GET['action'])) {
    if ($_GET['action']=='logout') {
      session_destroy();

      if (isset($_GET['url'])) {
        header("Location: {$_GET['url']}");
      }else {
        header("Location: login.php");
      }
    }else{
      header("Location: shopping.php");
    }
  }
 ?>
