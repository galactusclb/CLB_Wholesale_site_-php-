<?php
define('EMAIL','clbtrollwarlord@gmail.com');
define('PASS','Chanaka123@');
