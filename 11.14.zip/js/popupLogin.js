//////////////////////////////////////
//login check
    // $(document).load(function () {
    // var element = $("input#popScript").val();
    // //code to execute
    // }

    function loginCheck(){
      var uname=document.getElementById("uname").value;

      if (uname=="") {
        document.getElementById("div-popup").style.display="block";
        document.getElementById("div-popup-login").style.display="block";
        return false;
      }else{
        return true;
      }
    }

    function popDivClose() {
      document.getElementById("div-popup").style.display="none";
      document.getElementById("div-popup-login").style.display="none";
    }
